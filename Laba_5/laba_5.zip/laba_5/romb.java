package laba_5;

import java.awt.*;

public class romb extends Shape{


    int radius, width, length , rand;



    public romb(int radius, int width, int length) {

        this.radius = radius;

        this.width = width;

        this.length = length;


    }



    public void paint(Graphics h){

        for (int i=0;i<9;i++){

            int x=1000-(int)(Math.random()*(999-1+1));
            int y=1000-(int)(Math.random()*(999-1+1));
            System.out.println(x+ " ");

            rand=7;

            if(rand==1) h.setColor(Color.BLACK);

            else if(rand==2) h.setColor(Color.cyan);

            else if(rand==3) h.setColor(Color.BLUE);

            else if(rand==4) h.setColor(Color.pink);

            else if(rand==5) h.setColor(Color.magenta);

            else if(rand==6) h.setColor(Color.yellow);

            else if(rand==7) h.setColor(Color.red);

            else if(rand==8) h.setColor(Color.green);

            else if(rand==9) h.setColor(Color.BLUE);

            //h.drawOval(100,100,width,length);
            h.fillOval(x,y,width,length);



        }



    }

}