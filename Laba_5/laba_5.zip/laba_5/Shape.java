package laba_5;

import javax.swing.*;

import java.awt.*;



public class Shape extends JPanel {



    public Shape() {

    }



    void back(){

        this.setBackground(new Color(255, 20, 147));

    }



}